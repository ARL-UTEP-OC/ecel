#!/bin/bash



### Configure shell
#
set -e
set -u



### Include main _bootstrap.sh
#
. `dirname $BASH_SOURCE`/../_bootstrap.sh
